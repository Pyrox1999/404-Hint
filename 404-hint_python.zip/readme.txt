This program sends a quirky request on the website you enter:

This systems it may discover:

WordPress,nginx, Apache, IIS, Drupal, Joomla, Django, Rails, ASP.NET, Tomcat